import React, { useState, useEffect, useMemo } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Scanning } from './components/Scanning';
import { ResultCard } from './components/ResultCard';
import { Preloader } from './components/Preloader'; // Import Preloader
import { Footer } from './components/Footer'; // Import Footer
import { DNS_LIST } from './constants';
import { DnsResult, AppState, UserConnection } from './types';
import { RefreshCw, ArrowRight, Activity, Terminal } from 'lucide-react';
import { AnimatePresence, motion } from 'framer-motion';
import { runBatchTest } from './services/pingService';

const App: React.FC = () => {
  const [loading, setLoading] = useState(true); // Preloader state
  const [state, setState] = useState<AppState>('home');
  const [results, setResults] = useState<DnsResult[]>([]);
  const [progress, setProgress] = useState(0);
  const [currentTesting, setCurrentTesting] = useState('');
  const [connection, setConnection] = useState<UserConnection | null>(null);
  
  // Theme Management - Force Dark for Cyberpunk theme
  const [isDark, setIsDark] = useState(true);

  useEffect(() => {
    // Check system preference or default
    if (document.documentElement.classList.contains('dark')) {
      setIsDark(true);
    }

    // Advanced ISP Detection with WebRTC Leak Attempt
    const detectISP = async () => {
      // Helper to check if IP is public (not local)
      const isPublicIP = (ip: string) => {
        const parts = ip.split('.').map(Number);
        if (parts[0] === 10) return false;
        if (parts[0] === 172 && parts[1] >= 16 && parts[1] <= 31) return false;
        if (parts[0] === 192 && parts[1] === 168) return false;
        if (parts[0] === 127) return false;
        return true;
      };

      let detectedRealIp = '';

      // 1. Try WebRTC to find real IP (Bypasses some VPN/Proxy configurations)
      try {
        const rtcPromise = new Promise<string>((resolve) => {
             const pc = new RTCPeerConnection({ iceServers: [{ urls: "stun:stun.l.google.com:19302" }] });
             pc.createDataChannel("");
             pc.createOffer().then(o => pc.setLocalDescription(o));
             
             let resolved = false;
             
             pc.onicecandidate = (ice) => {
                 if (!resolved && ice && ice.candidate && ice.candidate.candidate) {
                     const match = ice.candidate.candidate.match(/([0-9]{1,3}(\.[0-9]{1,3}){3})/);
                     if (match && isPublicIP(match[1])) {
                         resolved = true;
                         pc.close();
                         resolve(match[1]);
                     }
                 }
             };
             
             // Timeout after 1s
             setTimeout(() => {
                 if (!resolved) {
                    // Cleanup
                    try { pc.close(); } catch(e){}
                    resolve('');
                 }
             }, 1000);
        });
        detectedRealIp = await rtcPromise;
      } catch (e) {
        console.log('WebRTC detection blocked or failed', e);
      }

      // 2. Fallback Strategy for API Calls
      const apiSources = [
        // Strategy A: ipwho.is (Best data)
        async () => {
           const endpoint = detectedRealIp ? `https://ipwho.is/${detectedRealIp}` : 'https://ipwho.is/';
           const res = await fetch(endpoint);
           const data = await res.json();
           if (!data.success) throw new Error('API Success False');
           return {
             ip: data.ip,
             isp: data.connection?.isp || data.connection?.org || data.isp,
             country: data.country,
             city: data.city
           };
        },
        // Strategy B: ipapi.co (Reliable fallback)
        async () => {
           const res = await fetch('https://ipapi.co/json/');
           const data = await res.json();
           if (data.error) throw new Error('API Error');
           return {
             ip: data.ip,
             isp: data.org || data.asn,
             country: data.country_name,
             city: data.city
           };
        },
        // Strategy C: db-ip.com (Simple, no ISP usually but gets Location)
        async () => {
            const res = await fetch('https://api.db-ip.com/v2/free/self');
            const data = await res.json();
            return {
                ip: data.ipAddress,
                isp: 'Unknown ISP', 
                country: data.countryName,
                city: data.city
            };
        }
      ];

      // Execute Strategies Sequentially
      for (const strategy of apiSources) {
          try {
              const result = await strategy();
              setConnection(result);
              return; // Exit on first success
          } catch (e) {
              // Continue to next strategy
          }
      }

      // Final Fallback (If offline or all APIs blocked)
      console.warn("All ISP detection methods failed.");
      setConnection({
          ip: detectedRealIp || '127.0.0.1',
          isp: 'Network Unavailable',
          country: 'Unknown',
          city: 'Unknown'
      });
    };

    detectISP();
  }, []);

  const toggleTheme = () => {
    // For this design, we prefer dark mode, but functionality remains
    if (isDark) {
      document.documentElement.classList.remove('dark');
      setIsDark(false);
    } else {
      document.documentElement.classList.add('dark');
      setIsDark(true);
    }
  };

  const startScan = async () => {
    setState('scanning');
    setResults([]);
    setProgress(0);

    const tempResults: DnsResult[] = [];
    const total = DNS_LIST.length;
    let completed = 0;

    await runBatchTest(DNS_LIST, (result) => {
      tempResults.push(result);
      completed++;
      setProgress((completed / total) * 100);
      setCurrentTesting(result.primary);
    });

    const sorted = tempResults.sort((a, b) => {
      // Prioritize success
      if (a.status !== 'success' && b.status === 'success') return 1;
      if (a.status === 'success' && b.status !== 'success') return -1;
      // Then latency
      return a.latency - b.latency;
    });

    setResults(sorted);
    setState('results');
  };

  const handleRestart = () => {
    setState('home');
    setResults([]);
  };

  // Grouping Logic
  const processedResults = useMemo(() => {
    const groups: Record<string, DnsResult[]> = {};
    results.forEach(item => {
      if (!groups[item.provider]) {
        groups[item.provider] = [];
      }
      groups[item.provider].push(item);
    });

    const finalDisplayList: DnsResult[] = [];
    Object.values(groups).forEach(group => {
      const sortedGroup = group.sort((a, b) => a.latency - b.latency);
      const best = sortedGroup[0];
      if (sortedGroup.length > 1) {
        best.variants = sortedGroup.slice(1);
      }
      finalDisplayList.push(best);
    });

    return finalDisplayList.sort((a, b) => {
         if (a.status !== 'success' && b.status === 'success') return 1;
         if (a.status === 'success' && b.status !== 'success') return -1;
         return a.latency - b.latency;
    });
  }, [results]);

  return (
    <>
      <AnimatePresence>
        {loading && <Preloader onComplete={() => setLoading(false)} />}
      </AnimatePresence>

      {!loading && (
        <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
            className="min-h-screen text-slate-200"
        >
          <Header isDark={isDark} toggleTheme={toggleTheme} />
          
          <main className="container mx-auto pb-20 pt-8 relative">
            {state === 'home' && (
              <Hero onStart={startScan} connection={connection} />
            )}

            {state === 'scanning' && (
              <Scanning progress={progress} currentDns={currentTesting} connection={connection} />
            )}

            {state === 'results' && (
              <div className="max-w-5xl mx-auto px-4">
                <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex flex-col md:flex-row items-center justify-between mb-8 gap-4 bg-white/5 p-6 rounded-2xl border border-white/5 backdrop-blur-md"
                >
                  <div>
                    <h2 className="text-3xl font-black text-white mb-2 flex items-center gap-2">
                      <Terminal className="text-primary" />
                      SYSTEM REPORT
                    </h2>
                    <p className="text-slate-400 font-mono text-xs">
                       OPTIMIZED FOR: <span className="text-emerald-400 font-bold">{connection?.isp || 'UNKNOWN NETWORK'}</span>
                    </p>
                  </div>
                  <button 
                    onClick={handleRestart}
                    className="flex items-center gap-2 px-6 py-3 bg-white text-black font-black rounded-xl hover:bg-primary hover:text-white transition-all shadow-[0_0_15px_rgba(255,255,255,0.2)]"
                  >
                    <RefreshCw className="w-4 h-4" />
                    NEW SCAN
                  </button>
                </motion.div>

                {/* Staggered Results List */}
                <motion.div 
                    initial="hidden"
                    animate="visible"
                    variants={{
                        visible: { transition: { staggerChildren: 0.1 } }
                    }}
                    className="space-y-4"
                >
                  {processedResults.slice(0, 50).map((result, index) => (
                    <ResultCard 
                      key={result.id} 
                      data={result} 
                      rank={index + 1} 
                    />
                  ))}
                </motion.div>
                
                <div className="mt-16 text-center border-t border-white/10 pt-8">
                  <p className="text-slate-600 text-[10px] mb-4 font-mono tracking-[0.3em]">
                    SECURE CONNECTION ESTABLISHED
                  </p>
                  <button onClick={handleRestart} className="text-primary hover:text-white flex items-center justify-center gap-2 mx-auto font-bold transition-colors">
                    RETURN TO ROOT <ArrowRight className="w-4 h-4 rotate-180" />
                  </button>
                </div>
              </div>
            )}
          </main>
          <Footer />
        </motion.div>
      )}
    </>
  );
};

export default App;