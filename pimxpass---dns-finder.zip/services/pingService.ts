import { DnsProvider, DnsResult } from "../types";

// Helper to calculate standard deviation for Jitter
const calculateJitter = (arr: number[]): number => {
  if (arr.length < 2) return 0;
  const mean = arr.reduce((a, b) => a + b, 0) / arr.length;
  const variance = arr.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / arr.length;
  return Math.round(Math.sqrt(variance));
};

export const measureLatency = async (ip: string): Promise<number> => {
  const start = performance.now();
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 2000); // 2s timeout per ping

  try {
    // Attempt HTTPS fetch with no-cors to bypass browser security blocks for timing
    // Random query param prevents caching
    await fetch(`https://${ip}/?_=${Math.random()}`, { 
      mode: 'no-cors', 
      signal: controller.signal,
      cache: 'no-store',
      // We accept that we can't read the body, we just want the round-trip time
    });
    
    clearTimeout(timeoutId);
    return Math.round(performance.now() - start);
  } catch (error: any) {
    // A fetch error (like connection refused) still means the packet traveled.
    // However, a timeout (AbortError) means packet loss or extreme lag.
    if (error.name === 'AbortError') return 9999;
    
    // If it's a network error (e.g. Protocol Error), likely the server exists but rejected the specific HTTPS request.
    // For DNS testing in browser, this is the closest we get to "Ping".
    // We treat immediate rejection as "Alive but low latency" vs Timeout.
    // To be conservative, if it fails, we return a high number unless we are sure.
    // For this specific logic, we'll allow fast failures to count if they were fast, 
    // but penalize them slightly to prefer open HTTPS servers (like Cloudflare/Google).
    return 9999; 
  }
};

export const runBatchTest = async (
  list: DnsProvider[], 
  onProgress: (result: DnsResult) => void
) => {
  // Batch size restricted to prevent browser network throttling
  const BATCH_SIZE = 4;
  const PINGS_PER_SERVER = 3; // Ping 3 times for accuracy

  for (let i = 0; i < list.length; i += BATCH_SIZE) {
    const batch = list.slice(i, i + BATCH_SIZE);
    
    const promises = batch.map(async (dns) => {
      const pings: number[] = [];
      let successCount = 0;

      // Run multiple pings
      for (let j = 0; j < PINGS_PER_SERVER; j++) {
        const latency = await measureLatency(dns.primary);
        if (latency < 3000) {
          pings.push(latency);
          successCount++;
        }
        // Small delay between pings to simulate real interval
        await new Promise(r => setTimeout(r, 50));
      }

      // Calculate stats
      const avgLatency = pings.length > 0 
        ? Math.round(pings.reduce((a, b) => a + b, 0) / pings.length) 
        : 9999;
      
      const jitter = calculateJitter(pings);
      const successRate = (successCount / PINGS_PER_SERVER) * 100;

      const result: DnsResult = {
        ...dns,
        latency: avgLatency,
        jitter: jitter,
        successRate: successRate,
        rawPings: pings,
        status: avgLatency < 3000 && successRate > 0 ? 'success' : 'failed'
      };
      
      onProgress(result);
    });

    await Promise.all(promises);
    await new Promise(r => setTimeout(r, 150)); // Cooldown between batches
  }
};