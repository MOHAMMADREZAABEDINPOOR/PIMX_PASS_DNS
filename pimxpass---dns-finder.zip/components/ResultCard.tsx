import React, { useState } from 'react';
import { Copy, Check, Server, Globe, ChevronDown, ChevronUp, Signal, Zap, Info } from 'lucide-react';
import { DnsResult } from '../types';
import { motion, AnimatePresence } from 'framer-motion';

interface ResultCardProps {
  data: DnsResult;
  rank: number;
}

export const ResultCard: React.FC<ResultCardProps> = ({ data, rank }) => {
  const [copied, setCopied] = useState<string | null>(null);
  const [expanded, setExpanded] = useState(false);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(key);
    setTimeout(() => setCopied(null), 2000);
  };

  const isTopRank = rank <= 3;
  const rankColors = {
      1: 'from-yellow-500 to-orange-500',
      2: 'from-slate-300 to-slate-400',
      3: 'from-orange-700 to-amber-800'
  };

  const getLatencyColor = (ms: number) => {
      if (ms < 50) return 'text-emerald-400';
      if (ms < 100) return 'text-emerald-200';
      if (ms < 180) return 'text-yellow-400';
      return 'text-rose-400';
  };

  return (
    <motion.div
      layout
      variants={{
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0 }
      }}
      whileHover={{ y: -2, transition: { duration: 0.2 } }}
      className={`relative rounded-2xl overflow-hidden group border border-white/5 bg-[#0F0F0F]/80 backdrop-blur-sm`}
    >
        {/* Glow Effect on Hover */}
        <div className="absolute -inset-px bg-gradient-to-r from-primary to-accent opacity-0 group-hover:opacity-30 transition-opacity duration-500 blur-sm rounded-2xl pointer-events-none"></div>

        {/* Top Rank Highlight Line */}
        {isTopRank && (
            <div className={`absolute top-0 left-0 w-1 h-full bg-gradient-to-b ${rankColors[rank as keyof typeof rankColors]} opacity-80`}></div>
        )}

        <div className="p-5 relative z-10">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                
                {/* Left: Info */}
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1">
                        <div className={`flex items-center justify-center w-8 h-8 rounded-lg font-black font-mono text-sm ${isTopRank ? 'bg-white text-black' : 'bg-white/10 text-white'}`}>
                            #{rank}
                        </div>
                        <h3 className="text-xl font-bold text-white truncate">{data.name}</h3>
                        {data.location && (
                             <span className="hidden sm:inline-flex px-2 py-0.5 rounded text-[10px] bg-white/5 text-slate-400 border border-white/5 uppercase tracking-wide">
                                 {data.location}
                             </span>
                        )}
                    </div>
                    <div className="flex flex-wrap gap-2 pl-11">
                         {data.tags.slice(0, 3).map(tag => (
                             <span key={tag} className="text-[10px] text-slate-400 font-mono bg-white/5 px-1.5 py-0.5 rounded">
                                 {tag}
                             </span>
                         ))}
                    </div>
                </div>

                {/* Center: Metrics */}
                <div className="flex items-center gap-4 pl-11 md:pl-0">
                    <div className="text-right">
                        <div className={`text-2xl font-black font-mono leading-none ${getLatencyColor(data.latency)}`}>
                            {data.latency}<span className="text-xs ml-1 opacity-50">ms</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Latency</div>
                    </div>
                    <div className="w-px h-8 bg-white/10"></div>
                    <div className="text-right">
                        <div className="text-lg font-bold font-mono text-slate-300 leading-none">
                            {data.jitter}<span className="text-xs ml-1 opacity-50">ms</span>
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wider">Jitter</div>
                    </div>
                </div>

                {/* Right: Copy IPs (Compact) */}
                <div className="flex flex-col gap-2 w-full md:w-auto">
                    <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1 pr-3 border border-white/5 hover:border-white/20 transition-colors">
                         <button 
                            onClick={() => handleCopy(data.primary, 'primary')} 
                            className="p-1.5 rounded bg-white/10 hover:bg-emerald-500 hover:text-black text-slate-400 transition-colors"
                         >
                            {copied === 'primary' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                         </button>
                         <code className="font-mono text-sm text-slate-300">{data.primary}</code>
                         <span className="text-[10px] text-slate-600 ml-auto font-mono">PRI</span>
                    </div>
                    <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1 pr-3 border border-white/5 hover:border-white/20 transition-colors">
                         <button 
                            onClick={() => handleCopy(data.secondary, 'secondary')} 
                            className="p-1.5 rounded bg-white/10 hover:bg-emerald-500 hover:text-black text-slate-400 transition-colors"
                         >
                            {copied === 'secondary' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                         </button>
                         <code className="font-mono text-sm text-slate-300">{data.secondary}</code>
                         <span className="text-[10px] text-slate-600 ml-auto font-mono">SEC</span>
                    </div>
                </div>
            </div>
            
            {/* Description & Expansion Trigger */}
            <div className="mt-4 pt-3 border-t border-white/5 flex items-center justify-between">
                <p className="text-xs text-slate-500 line-clamp-1 flex-1 pr-4">
                    {data.description || 'No specific description available for this server.'}
                </p>
                <button 
                    onClick={() => setExpanded(!expanded)} 
                    className="text-xs font-bold text-primary hover:text-white transition-colors flex items-center gap-1"
                >
                    {expanded ? 'LESS' : 'MORE'} INFO <ChevronDown className={`w-3 h-3 transition-transform ${expanded ? 'rotate-180' : ''}`} />
                </button>
            </div>
        </div>

        {/* Expanded Content */}
        <AnimatePresence>
            {expanded && (
                <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="bg-black/20 border-t border-white/5"
                >
                    <div className="p-5 grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* IPv6 */}
                        <div>
                            <h4 className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
                                <Globe className="w-3 h-3" /> IPv6 Protocols
                            </h4>
                            {data.primaryIPv6 ? (
                                <div className="space-y-2">
                                    <div onClick={() => handleCopy(data.primaryIPv6!, 'v6p')} className="cursor-pointer group/v6 p-2 rounded border border-dashed border-slate-700 hover:border-emerald-500/50 transition-colors">
                                        <div className="text-[10px] text-slate-500 mb-1">PRIMARY IPv6</div>
                                        <code className="text-xs text-slate-300 font-mono break-all">{data.primaryIPv6}</code>
                                    </div>
                                    {data.secondaryIPv6 && (
                                        <div onClick={() => handleCopy(data.secondaryIPv6!, 'v6s')} className="cursor-pointer group/v6 p-2 rounded border border-dashed border-slate-700 hover:border-emerald-500/50 transition-colors">
                                            <div className="text-[10px] text-slate-500 mb-1">SECONDARY IPv6</div>
                                            <code className="text-xs text-slate-300 font-mono break-all">{data.secondaryIPv6}</code>
                                        </div>
                                    )}
                                </div>
                            ) : (
                                <div className="text-xs text-slate-600 italic">No IPv6 available</div>
                            )}
                        </div>

                        {/* Variants */}
                        <div>
                             <h4 className="text-[10px] text-slate-500 font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
                                <Server className="w-3 h-3" /> Alternative Nodes
                            </h4>
                            {data.variants && data.variants.length > 0 ? (
                                <div className="space-y-2">
                                    {data.variants.map((v, i) => (
                                        <div key={i} className="flex items-center justify-between p-2 bg-white/5 rounded">
                                            <div className="flex items-center gap-2">
                                                <div className={`w-1.5 h-1.5 rounded-full ${v.latency < 150 ? 'bg-emerald-500' : 'bg-yellow-500'}`}></div>
                                                <span className="text-xs text-slate-300 font-bold">{v.name}</span>
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <span className="text-xs font-mono text-slate-400">{v.latency}ms</span>
                                                <button onClick={() => handleCopy(v.primary, `v${i}`)} className="text-[10px] px-2 py-1 bg-white/10 rounded hover:bg-primary hover:text-white transition-colors">
                                                    COPY
                                                </button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            ) : (
                                <div className="text-xs text-slate-600 italic">No alternative nodes detected.</div>
                            )}
                        </div>
                    </div>
                </motion.div>
            )}
        </AnimatePresence>
    </motion.div>
  );
};