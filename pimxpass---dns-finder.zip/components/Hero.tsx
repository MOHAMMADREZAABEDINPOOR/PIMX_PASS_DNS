import React from 'react';
import { Zap, ShieldAlert, Globe2, Bot, Send, Server, Activity, Lock, ArrowRight, ChevronRight, Play, Smartphone, Music } from 'lucide-react';
import { motion } from 'framer-motion';
import { UserConnection } from '../types';

interface HeroProps {
  onStart: () => void;
  connection: UserConnection | null;
}

// Animation Variants
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } }
};

export const Hero: React.FC<HeroProps> = ({ onStart, connection }) => {
  return (
    <div className="relative min-h-screen flex flex-col items-center pt-32 pb-20 px-4 overflow-hidden">
      
      {/* Dynamic Background Effects */}
      <div className="absolute inset-0 pointer-events-none -z-10">
        {/* Animated Gradient Mesh */}
        <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] animate-pulse-slow"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-blue-600/10 rounded-full blur-[120px] animate-pulse-slow"></div>
        
        {/* Grid Floor */}
        <div className="perspective-grid opacity-20"></div>
      </div>

      <motion.div 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-7xl w-full mx-auto relative z-10 space-y-20"
      >
        
        {/* --- HEADER SECTION --- */}
        <div className="text-center space-y-8">
            <motion.div variants={itemVariants} className="inline-flex items-center justify-center">
                 <div className="px-4 py-1.5 rounded-full border border-primary/20 bg-primary/5 backdrop-blur-md text-primary text-xs font-mono font-bold tracking-widest shadow-[0_0_20px_rgba(99,102,241,0.2)]">
                    NEXT GEN DNS SCANNER
                 </div>
            </motion.div>

            <motion.h1 variants={itemVariants} className="text-6xl md:text-8xl lg:text-9xl font-black text-white tracking-tighter leading-[0.9]">
                <span className="block hover:text-transparent hover:bg-clip-text hover:bg-gradient-to-r hover:from-white hover:via-slate-200 hover:to-slate-400 transition-all duration-500 cursor-default">
                  PIMX
                </span>
                <span className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-indigo-400 to-cyan-300 animate-gradient-x">
                  PASS
                </span>
            </motion.h1>

            <motion.p variants={itemVariants} className="max-w-2xl mx-auto text-lg md:text-xl text-slate-400 font-light leading-relaxed">
                ابزار حرفه‌ای عبور از تحریم و کاهش پینگ. <br className="hidden md:block"/>
                <span className="text-white font-bold">شناسایی هوشمند</span> بهترین DNS بر اساس اینترنت شما.
            </motion.p>

            <motion.div variants={itemVariants} className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
                <button
                    onClick={onStart}
                    className="group relative w-full sm:w-auto px-10 py-5 bg-white text-black rounded-xl font-black text-lg overflow-hidden tracking-tight hover:scale-105 transition-transform duration-300"
                >
                    <div className="absolute inset-0 bg-gradient-to-r from-indigo-400 via-cyan-400 to-indigo-400 opacity-0 group-hover:opacity-100 transition-opacity duration-300 mix-blend-screen"></div>
                    <span className="relative flex items-center justify-center gap-3">
                        START SCANNING
                        <Play className="w-4 h-4 fill-black" />
                    </span>
                </button>
            </motion.div>
        </div>

        {/* --- PIMX PASS BOT SECTION --- */}
        <motion.div 
            variants={itemVariants}
            className="relative w-full rounded-[2.5rem] bg-[#050505] border border-white/10 overflow-hidden mb-12"
        >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-indigo-900/20 via-[#050505] to-[#050505]"></div>
            
            <div className="relative flex flex-col md:flex-row p-8 md:p-12 gap-12 items-center">
                <div className="w-full md:w-1/3 flex justify-center">
                    <div className="relative w-64 h-64 flex items-center justify-center">
                        <div className="absolute w-full h-full border border-primary/20 rounded-full animate-[spin_10s_linear_infinite]"></div>
                        <div className="absolute w-3/4 h-3/4 border border-indigo-400/20 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
                        <div className="w-32 h-32 bg-[#0A0A0A] border border-white/10 rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(99,102,241,0.2)] relative overflow-hidden group">
                            <ShieldAlert className="w-16 h-16 text-primary relative z-10" />
                            <div className="absolute inset-0 bg-primary/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        </div>
                        <div className="absolute top-0 left-1/2 w-3 h-3 bg-primary rounded-full shadow-[0_0_15px_#6366f1] animate-pulse"></div>
                    </div>
                </div>

                <div className="flex-1 text-right" dir="rtl">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold tracking-wider mb-4">
                        <Zap className="w-3 h-3" />
                        MAJOR UPDATE v2.0
                    </div>
                    
                    <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
                        آپدیت جدید بات <span className="text-transparent bg-clip-text bg-gradient-to-l from-primary to-indigo-300">PIMX PASS</span>
                    </h2>

                    <div className="space-y-4 text-slate-400 leading-8 mb-8 text-lg font-light">
                        <p className="text-white font-bold">🚀 آپدیت جدید بات PIMX PASS منتشر شد 🚀</p>
                        <p>بالاخره بعد از کلی کار و بهبود، بات PIMX آپدیت شد و کلی قابلیت جدید بهش اضافه شده 👌</p>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
                            <div className="bg-white/5 p-4 rounded-2xl border border-white/5">
                                <h4 className="text-white font-bold mb-2">📌 قبلاً چی داشت؟</h4>
                                <ul className="text-sm space-y-1">
                                    <li>• پروکسی‌های تلگرام</li>
                                    <li>• سرورهای ویتوری (V2Ray)</li>
                                </ul>
                            </div>
                            <div className="bg-primary/10 p-4 rounded-2xl border border-primary/20">
                                <h4 className="text-primary font-bold mb-2">📌 الان چی اضافه شده؟ 👇</h4>
                                <ul className="text-sm space-y-1 text-slate-300">
                                    <li>🟢 OpenVPN</li>
                                    <li>🟢 HA Tunnel Plus</li>
                                    <li>🟢 NPV Tunnel</li>
                                    <li>🟢 HTTP Custom</li>
                                    <li>🟢 HTTP Injector</li>
                                </ul>
                            </div>
                        </div>
                        <p className="mt-4 text-sm">🌐 چندین نوع سرور و تانل مختلف در یک بات برای انتخاب راحت‌تر و تنوع بیشتر برای اتصال پایدار.</p>
                    </div>

                    <div className="flex flex-wrap gap-4">
                        <a 
                            href="https://t.me/PIMX_PASS_BOT" 
                            target="_blank"
                            rel="noreferrer"
                            className="flex-1 md:flex-none px-8 py-4 rounded-2xl bg-primary hover:bg-indigo-500 text-white font-bold transition-all shadow-lg hover:shadow-primary/30 flex items-center justify-center gap-3 group"
                        >
                            <Bot className="w-5 h-5" />
                            ورود به بات
                            <ChevronRight className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
                        </a>
                        <a 
                            href="https://t.me/PIMX_PASS" 
                            target="_blank"
                            rel="noreferrer"
                            className="flex-1 md:flex-none px-8 py-4 rounded-2xl bg-[#0A0A0A] border border-white/10 text-white hover:bg-white/5 font-bold transition-all flex items-center justify-center gap-3"
                        >
                            <Send className="w-5 h-5 text-primary" />
                            عضویت کانال
                        </a>
                    </div>
                </div>
            </div>
        </motion.div>

        {/* --- PIMXPLAY SECTION --- */}
        <motion.div 
            variants={itemVariants}
            className="relative w-full rounded-[2.5rem] bg-[#050505] border border-white/10 overflow-hidden mb-12"
        >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-emerald-900/20 via-[#050505] to-[#050505]"></div>
            
            <div className="relative flex flex-col md:flex-row-reverse p-8 md:p-12 gap-12 items-center">
                <div className="w-full md:w-1/3 flex justify-center">
                    <div className="relative w-64 h-64 flex items-center justify-center">
                        <div className="absolute w-full h-full border border-emerald-500/20 rounded-full animate-[spin_12s_linear_infinite]"></div>
                        <div className="w-32 h-32 bg-[#0A0A0A] border border-white/10 rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(16,185,129,0.2)] relative overflow-hidden group">
                            <Smartphone className="w-16 h-16 text-emerald-500 relative z-10" />
                            <div className="absolute inset-0 bg-emerald-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        </div>
                    </div>
                </div>

                <div className="flex-1 text-right" dir="rtl">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-bold tracking-wider mb-4">
                        <Smartphone className="w-3 h-3" />
                        ANDROID APP HUNTER
                    </div>
                    
                    <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
                        دانلود مستقیم با <span className="text-transparent bg-clip-text bg-gradient-to-l from-emerald-400 to-teal-300">PIMXPLAY</span>
                    </h2>

                    <p className="text-slate-400 leading-8 mb-8 text-lg font-light">
                        وقتی اینترنت کند میشه یا اختلال داره، ممکنه با سختی به تلگرام وصل بشیم 📶 اما باز کردن گوگل‌پلی، سایت‌های دانلود برنامه یا لینک‌های خارجی خیلی سخت‌تر میشه 😵💫 اینجاست که <span className="text-white font-bold">PIMXPLAY</span> به درد می‌خوره ✅ آخرین نسخه‌ی اپ‌های اندروید رو مستقیم داخل تلگرام بهت میده.
                    </p>

                    <div className="grid grid-cols-2 gap-4 mb-8">
                        <div className="flex items-center gap-2 text-slate-300 text-sm">
                            <ChevronRight className="w-4 h-4 text-emerald-500" />
                            🔍 جستجوی هوشمند: فقط اسم برنامه
                        </div>
                        <div className="flex items-center gap-2 text-slate-300 text-sm">
                            <ChevronRight className="w-4 h-4 text-emerald-500" />
                            🔗 پشتیبانی از لینک گوگل‌پلی
                        </div>
                        <div className="flex items-center gap-2 text-slate-300 text-sm">
                            <ChevronRight className="w-4 h-4 text-emerald-500" />
                            📦 دریافت APK: نصب سریع و راحت
                        </div>
                        <div className="flex items-center gap-2 text-slate-300 text-sm">
                            <ChevronRight className="w-4 h-4 text-emerald-500" />
                            🛡 فایل‌های مطمئن و تست شده
                        </div>
                    </div>

                    <a 
                        href="https://t.me/PIMX_SONIC_BOT" 
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex px-8 py-4 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-all shadow-lg hover:shadow-emerald-600/30 items-center justify-center gap-3 group"
                    >
                        <Bot className="w-5 h-5" />
                        شروع دانلود اپلیکیشن
                    </a>
                </div>
            </div>
        </motion.div>

        {/* --- PIMXSONIC SECTION --- */}
        <motion.div 
            variants={itemVariants}
            className="relative w-full rounded-[2.5rem] bg-[#050505] border border-white/10 overflow-hidden mb-20"
        >
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,_var(--tw-gradient-stops))] from-rose-900/20 via-[#050505] to-[#050505]"></div>
            
            <div className="relative flex flex-col md:flex-row p-8 md:p-12 gap-12 items-center">
                <div className="w-full md:w-1/3 flex justify-center">
                    <div className="relative w-64 h-64 flex items-center justify-center">
                        <div className="absolute w-full h-full border border-rose-500/20 rounded-full animate-pulse"></div>
                        <div className="w-32 h-32 bg-[#0A0A0A] border border-white/10 rounded-3xl flex items-center justify-center shadow-[0_0_50px_rgba(244,63,94,0.2)] relative overflow-hidden group">
                            <Music className="w-16 h-16 text-rose-500 relative z-10" />
                            <div className="absolute inset-0 bg-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                        </div>
                    </div>
                </div>

                <div className="flex-1 text-right" dir="rtl">
                    <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-bold tracking-wider mb-4">
                        <Music className="w-3 h-3" />
                        OFFLINE MUSIC PLAYER
                    </div>
                    
                    <h2 className="text-4xl md:text-5xl font-black text-white mb-6">
                        لذت موسیقی با <span className="text-transparent bg-clip-text bg-gradient-to-l from-rose-400 to-orange-300">PIMXSONIC</span>
                    </h2>

                    <p className="text-slate-400 leading-8 mb-8 text-lg font-light">
                        این بات ساخته شده برای زمانی که اینترنت قطع یا خیلی ضعیف میشه و دسترسی به سایت‌ها سخت میشه 📶⚡️ <span className="text-white font-bold">PIMXSONIC</span> آماده است تا تو همین شرایط هم کارتون راه بیفته و لذت موسیقی رو بدون محدودیت تجربه کنید ✅
                    </p>

                    <a 
                        href="https://t.me/PIMX_PLAY_BOT" 
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex px-8 py-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition-all shadow-lg hover:shadow-rose-600/30 items-center justify-center gap-3 group"
                    >
                        <Music className="w-5 h-5" />
                        پخش موسیقی در تلگرام
                    </a>
                </div>
            </div>
        </motion.div>

      </motion.div>
    </div>
  );
};